# container_host

Enable rootless podman on rocky/rhel 

TODO:

Create meta dependencies to install poduser user from separate role
