# ansible-web_apps

Install nginx proxy along with various container based web apps on host running podman
