# ansible-firewall

Firewall role - mainly used as a dependency role for other roles to call for activities such as opening/closing ports and reloading firewalld.
