# ansible-mount_nas

Mounts NAS shares on linux server
