# ansible-rhel_sub_del

Remove host from RH Dev Subscription license
