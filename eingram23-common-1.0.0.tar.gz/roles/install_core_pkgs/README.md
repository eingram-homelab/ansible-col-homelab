# ansible-install_core_pkgs

Installs common packages to new server builds
